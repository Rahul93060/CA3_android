
package com.example.ca3

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.room.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "student")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
)

@Entity(tableName = "subject")
data class Subject(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val studentId: Int
)

data class StudentWithSubjects(
    @Embedded val student: Student,
    @Relation(
        parentColumn = "id",
        entityColumn = "studentId"
    )
    val subjects: List<Subject>
)

@Dao
interface StudentDao {

    @Insert
    suspend fun insertStudent(x: Student): Long

    @Insert
    suspend fun insertSubject(x: Subject)

    @Query("SELECT COUNT(*) FROM subject WHERE studentId = :x")
    suspend fun countSubjects(x: Int): Int

    @Query("SELECT EXISTS(SELECT 1 FROM student WHERE id = :x)")
    suspend fun studentExists(x: Int): Boolean

    @Transaction
    @Query("SELECT * FROM student")
    fun getStudentsWithSubjects(): Flow<List<StudentWithSubjects>>
}

@Database(
    entities = [Student::class, Subject::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun studentDao(): StudentDao

    companion object {
        @Volatile
        private var x: AppDatabase? = null

        fun getDatabase(context: android.content.Context): AppDatabase {
            return x ?: synchronized(this) {
                x ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "student_database"
                ).build().also { x = it }
            }
        }
    }
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val x = AppDatabase.getDatabase(this)

        setContent {
            MaterialTheme {
                StudentScreen(x.studentDao())
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentScreen(x: StudentDao) {

    var y by remember { mutableStateOf("") }
    var z by remember { mutableStateOf("") }
    var a by remember { mutableStateOf("") }

    val c = rememberCoroutineScope()
    val context = LocalContext.current

    val d by x.getStudentsWithSubjects()
        .collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        Text(
            "Student Subject Manager",
            style = MaterialTheme.typography.headlineSmall
        )

        OutlinedTextField(
            value = y,
            onValueChange = { y = it },
            label = { Text("Student Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                if (y.isNotBlank()) {
                    c.launch {
                        x.insertStudent(Student(name = y.trim()))
                        y = ""
                        Toast.makeText(
                            context,
                            "Student Added",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Add Student")
        }

        HorizontalDivider()

        Text("Add Subject", style = MaterialTheme.typography.titleLarge)

        OutlinedTextField(
            value = z,
            onValueChange = { z = it },
            label = { Text("Student ID") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number
            )
        )

        OutlinedTextField(
            value = a,
            onValueChange = { a = it },
            label = { Text("Subject Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                if (z.isNotBlank() && a.isNotBlank()) {
                    c.launch {
                        val id = z.toIntOrNull()

                        if ((id != null) && x.studentExists(id)) {
                            val count = x.countSubjects(id)

                            if (count < 3) {
                                x.insertSubject(
                                    Subject(
                                        name = a.trim(),
                                        studentId = id
                                    )
                                )

                                a = ""
                                z = ""

                                Toast.makeText(
                                    context,
                                    "Subject Added",
                                    Toast.LENGTH_SHORT
                                ).show()

                            } else {
                                Toast.makeText(
                                    context,
                                    "Limit reached! Only 3 subjects allowed.",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        } else {
                            Toast.makeText(
                                context,
                                "Invalid Student ID",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Add Subject")
        }

        HorizontalDivider()

        Text("Student List", style = MaterialTheme.typography.titleLarge)

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(d) { item ->

                Card(modifier = Modifier.fillMaxWidth()) {

                    Column(modifier = Modifier.padding(16.dp)) {

                        Text(
                            "ID: ${item.student.id}",
                            style = MaterialTheme.typography.labelMedium
                        )

                        Text(
                            item.student.name,
                            style = MaterialTheme.typography.titleMedium
                        )

                        Text(
                            "Subjects (${item.subjects.size}/3)",
                            style = MaterialTheme.typography.titleSmall
                        )

                        if (item.subjects.isEmpty()) {
                            Text("No subjects enrolled")
                        } else {
                            item.subjects.forEachIndexed { index, subject ->
                                Text("${index + 1}. ${subject.name}")
                            }
                        }
                    }
                }
            }
        }
    }
}
